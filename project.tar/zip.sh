#!/usr/bin/env bash
# zip_project.sh: Zips the entire project (excluding .git and .DS_Store) into project.zip in the root.

rm project.zip
tar.exe -a -c -f project.tar *