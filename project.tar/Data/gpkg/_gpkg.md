# Data

## Data sources will be generated in this folder. Will be included in the gitignore because it doesn't need to be on github. 