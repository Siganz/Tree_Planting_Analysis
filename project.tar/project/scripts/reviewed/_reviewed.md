# reviewed Folder

This folder contains:

- **ArcPy Scripts**  
  Reviewed ArcPy scripts that need to be refactored into helpers and included in the main pipeline.

> **After conversion:**  
> Move each refactored script into the `reviewed/` subfolder.
