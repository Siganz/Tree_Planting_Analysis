# This script is used to test the Python environment. Unimportant to the rest of the script. 
import sys
print("Running under:", sys.executable)
print("Python version:", sys.version)
print("Path:", sys.path)