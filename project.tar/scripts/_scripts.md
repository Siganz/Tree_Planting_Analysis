# Scripts

**Main scripts for the pipeline, first digit represents sequence**