# review Folder

This folder contains:

- **ArcPy Scripts**  
  Legacy `.py` files using ArcPy that need to be refactored into pure-Python scripts.

- **Model Flows**  
  Novel workflow diagrams and example flows included for reference.

> **After conversion:**  
> Move each refactored script into the `reviewed/` subfolder.
