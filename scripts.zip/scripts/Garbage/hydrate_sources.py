import requests
import json

def extract_view_id(url):
    return url.rstrip("/").split("/")[-1].split(".")[0]

def fetch_arcgis_metadata(url):
    resp = requests.get(f"{url}?f=json")
    data = resp.json()
    return {
        "geometry_type": data.get("geometryType"),
        "fields": [f["name"] for f in data.get("fields", [])]
    }

def fetch_socrata_metadata(view_id, app_token=None):
    headers = {"X-App-Token": app_token} if app_token else {}
    url = f"https://data.cityofnewyork.us/api/views/{view_id}.json"
    resp = requests.get(url, headers=headers)
    data = resp.json()
    return {
        "geometry_type": "Point" if any(col["dataTypeName"] == "point" for col in data["columns"]) else "Table",
        "fields": [col["fieldName"] for col in data["columns"]]
    }

def hydrate_sources(data_sources, app_token=None):
    for ds in data_sources:
        if ds["source_type"] == "arcgis_services":
            ds.update(fetch_arcgis_metadata(ds["url"]))
        elif ds["source_type"] == "socrata":
            view_id = extract_view_id(ds["url"])
            ds["view_id"] = view_id
            ds.update(fetch_socrata_metadata(view_id, app_token))
    return data_sources

# Example usage
if __name__ == "__main__":
    with open("data_sources.json") as f:
        sources = json.load(f)
    
    hydrated = hydrate_sources(sources, app_token="your_token_here")

    with open("layers.json", "w") as f:
        json.dump(hydrated, f, indent=2)
