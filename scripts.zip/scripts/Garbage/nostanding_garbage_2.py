import os
import pandas as pd
import arcpy

arcpy.env.overwriteOutput = True
scratch = arcpy.env.scratchGDB

# ── 0. Params ───────────────────────────────────────────────────────────────
# 0: csv_path, 1: sw_fc, 2: cen_fc, 3: out_fc, 4: desc_f, 5: side_f, 6: shift_ft
csv_path, sw_fc, cen_fc, out_fc, desc_f, side_f, shift_ft = [
    arcpy.GetParameterAsText(i) for i in range(7)
]
shift_ft = float(shift_ft)

# ── 0.1 Copy & integrate centerlines (don’t mutate source)───────────────────
cen_work = os.path.join(scratch, "cen_work")
arcpy.management.CopyFeatures(cen_fc, cen_work)
arcpy.management.Integrate(cen_work, "0.01 Feet")

# ── 1. load_filter() ─────────────────────────────────────────────────────────
def load_filter(csv_path, desc_f, side_f):
    df = pd.read_csv(csv_path)

    # normalize N/S/E/W
    df[side_f] = (df[side_f]
                  .astype(str).str.strip()
                  .str.upper().str[0]
                  .where(lambda s: s.isin(list("NSEW"))))
    df = df[df[side_f].notna()]

    # keep only our keywords
    keep = "NO STANDING|NO PARKING|HMP|TAXI|HOTEL|LOADING|PASSENGER"
    df = df[df[desc_f].str.upper().str.contains(keep, na=False)]

    # valid coords
    df = df[pd.to_numeric(df["sign_x_coord"], "coerce").notna()]
    df = df[pd.to_numeric(df["sign_y_coord"], "coerce").notna()]

    # dedupe on 1-ft grid
    df["x_r"] = df["sign_x_coord"].round(1)
    df["y_r"] = df["sign_y_coord"].round(1)
    df = df.drop_duplicates(subset=["x_r", "y_r"]).reset_index(drop=True)

    # parse arrow glyphs
    def _pa(s):
        s = str(s).upper()
        if "<->" in s:
            return "<->"
        elif "-->" in s or "->" in s:
            return "->"
        elif "<--" in s or "<-" in s:
            return "<-"
    df["parsed_arrow"] = df[desc_f].apply(_pa)
    df = df[df["parsed_arrow"].notna()]

    return df

# ── 1.  CSV → point feature class  ─────────────────────────────────────────
df = load_filter(csv_path, desc_f, side_f)
df["jid"] = df.index
tmp_csv = os.path.join(scratch, "clean_signs.csv")
df.to_csv(tmp_csv, index=False,
          columns=["jid", "sign_x_coord", "sign_y_coord", side_f, "parsed_arrow"])
arcpy.AddMessage(f"Cleaned signs CSV → {tmp_csv}")

sr = arcpy.SpatialReference(2263)          # NY State Plane Feet
signs = os.path.join(scratch, "signs_pts")
arcpy.management.XYTableToPoint(tmp_csv, signs,
                                "sign_x_coord", "sign_y_coord",
                                coordinate_system=sr)
arcpy.AddMessage(f"Signs → point FC: {signs}")

# ── 2.  Curb offset  ──────────────────────────────────────────────────────
signs_shifted = os.path.join(scratch, "signs_shifted")
arcpy.management.CopyFeatures(signs, signs_shifted)

with arcpy.da.UpdateCursor(signs_shifted, ["SHAPE@", side_f]) as cur:
    for shp, sd in cur:
        dx, dy = {"N": (0,  shift_ft),
                  "S": (0, -shift_ft),
                  "E": ( shift_ft, 0),
                  "W": (-shift_ft, 0)}.get((sd or "").upper(), (0, 0))
        pt = shp.centroid
        new_pt = arcpy.PointGeometry(arcpy.Point(pt.X + dx, pt.Y + dy), sr)
        cur.updateRow([new_pt, sd])

arcpy.AddMessage("↔️  Shifted signs off original location.")

# ── 3.  Build working sidewalk copy  ──────────────────────────────────────
arcpy.env.overwriteOutput = True
sw_work = os.path.join(scratch, "sw_work")
if arcpy.Exists(sw_work):
    arcpy.Delete_management(sw_work)
arcpy.management.CopyFeatures(sw_fc, sw_work)
arcpy.AddMessage(f"Copied sidewalks → {sw_work}")

# ── 4.  Snap curb‑shifted signs to their sidewalk  ────────────────────────
signs_snapped_sw = os.path.join(scratch, "signs_snapped_sw")
arcpy.management.CopyFeatures(signs_shifted, signs_snapped_sw)

near_sidewalk = os.path.join(scratch, "near_sidewalk")
arcpy.analysis.GenerateNearTable(signs_snapped_sw, sw_work, near_sidewalk,
                                 search_radius="60 Feet",
                                 location="NO_LOCATION",
                                 angle="NO_ANGLE",
                                 closest="CLOSEST")

arcpy.management.JoinField(signs_snapped_sw, "OBJECTID",
                           near_sidewalk, "IN_FID", ["NEAR_FID"])
arcpy.AddMessage("📌  Joined NEAR_FID onto curb‑shifted signs.")

# lookup:  sidewalk OID  →  geometry
sw_geom = {oid: g for oid, g in arcpy.da.SearchCursor(sw_work, ["OID@", "SHAPE@"])}

with arcpy.da.UpdateCursor(signs_snapped_sw, ["SHAPE@", "NEAR_FID"]) as cur:
    for shp, nid in cur:
        seg = sw_geom.get(nid)
        if seg:
            meas = seg.measureOnLine(shp.centroid)
            cur.updateRow([seg.positionAlongLine(meas), nid])

arcpy.AddMessage(f"Snapped signs → sidewalks: {signs_snapped_sw}")

# ── 4.2  Filter out signs that never snapped to a sidewalk ────────────────
sign_errors = os.path.join(scratch, "sign_errors")          # keep for QC

# copy rows where NEAR_FID is NULL  →  sign_errors
arcpy.analysis.Select(signs_snapped_sw, sign_errors, "NEAR_FID IS NULL")

# delete those same rows from the working sign layer
with arcpy.da.UpdateCursor(signs_snapped_sw, ["NEAR_FID"]) as cur:
    for nid, in cur:
        if nid is None:
            cur.deleteRow()

cnt_bad = int(arcpy.management.GetCount(sign_errors)[0])
arcpy.AddMessage(f"🛈  {cnt_bad} signs had no sidewalk within 60 ft → moved to sign_errors.")

# --- build a set of sidewalk OIDs that have at least one sign -------------
ids = {row[0] for row in arcpy.da.SearchCursor(signs_snapped_sw, ["NEAR_FID"])
        if row[0] is not None}

# bail early if nothing matched
if not ids:
    arcpy.AddWarning("No signs matched any sidewalk within 60 ft – aborting split.")
    raise SystemExit()

# create a comma‑separated string for SQL IN ()
id_list = ",".join(map(str, ids))

sw_work_filtered = os.path.join(scratch, "sw_work_has_sign")
arcpy.analysis.Select(sw_work,
                      sw_work_filtered,
                      f"OBJECTID IN ({id_list})")

arcpy.AddMessage(f"Sidewalks with signs → {sw_work_filtered} "
                 f"({len(ids)} segments)")

# ── 5.0  Split sidewalks at sign locations  ────────────────────────────────

# 1) filter sidewalks to those with matched signs (code above) -------------
sw_work = sw_work_filtered

# 2) create empty output FC
arcpy.management.CreateFeatureclass(scratch, "sw_split", "POLYLINE",
                                    template=sw_work, spatial_reference=sw_work)   # safe overwrite
sw_split = os.path.join(scratch, "sw_split")

# 3) load sign points once -------------------------------------------------
sign_pts = [row[0] for row in arcpy.da.SearchCursor(
               signs_snapped_sw, ["SHAPE@"])
            if row[0] is not None]

TOL = 1.0  # feet  (State‑Plane ft in EPSG 2263)

# 4) split loop with distance guard ---------------------------------------
with arcpy.da.SearchCursor(sw_work,  ["SHAPE@"]) as lcur, \
     arcpy.da.InsertCursor(sw_split, ["SHAPE@"]) as icur:

    for (line,) in lcur:
        # points genuinely near this sidewalk
        on_line = [pt for pt in sign_pts if line.distanceTo(pt) <= TOL]
        if not on_line:
            continue                          # skip if no sign

        on_line.sort(key=lambda p: line.measureOnLine(p))

        pieces = [line]
        for pt in on_line:                    # A, B, C …
            new_pieces = []
            for seg in pieces:                # evolving child segments
                if seg.distanceTo(pt) > TOL:  # point not on this child
                    new_pieces.append(seg)
                    continue

                # Safe: point is on seg
                foot, _, _, _ = seg.queryPointAndDistance(pt, use_percentage=False)
                cuts = seg.cut(foot)          # never throws now
                new_pieces.extend(cuts or [seg])
            pieces = new_pieces

        for seg in pieces:
            icur.insertRow([seg])

arcpy.AddMessage(f"Split sidewalks written → {sw_split}")

# ------------------------------------------------------------
# 4.  tag 'before' vs 'after' using endpoint‑touch logic
# ------------------------------------------------------------
arrow_map = {"->": "after", "<-": "before", "<->": "both"}

# 1) OID field on the freshly‑split sidewalks
seg_oid = arcpy.Describe(sw_split).OIDFieldName      # usually "OBJECTID"

# 2) Path for the joined output
sw_split_joined = os.path.join(scratch, "sw_split_joined")

# 3) Run the spatial join ONLY if the field isn’t there yet
if "SIGN_OID" not in [f.name for f in arcpy.ListFields(sw_split)]:
    arcpy.analysis.SpatialJoin(
        target_features   = sw_split,          # sidewalk segments
        join_features     = signs_snapped_sw,  # <- use the *snapped‑to‑sidewalk* sign layer
        out_feature_class = sw_split_joined,
        join_operation    = "JOIN_ONE_TO_ONE", # or "JOIN_ONE_TO_MANY" if you want every pair
        match_option      = "INTERSECT"
    )

    # Replace TARGET_FID with a clearer name
    arcpy.management.AlterField(sw_split_joined, "TARGET_FID", new_field_name="SIGN_OID")

    # Point to the joined FC for the rest of the pipeline
    sw_split = sw_split_joined

# -------------------------------------------------------------------
# helper dicts
sign_arrow = {oid: arr for oid, arr
              in arcpy.da.SearchCursor(signs_snapped_sw,
                                       ["OBJECTID","parsed_arrow"])}
sign_geom  = {oid: geom for oid, geom
              in arcpy.da.SearchCursor(signs_snapped_sw,
                                       ["OBJECTID","SHAPE@"])}

def same(pt, sig_pt, tol=0.05):                   # ~½‑inch tol
    return abs(pt.X - sig_pt.X) < tol and abs(pt.Y - sig_pt.Y) < tol
# -------------------------------------------------------------------
if "no_stand" not in [f.name for f in arcpy.ListFields(sw_split)]:
    arcpy.management.AddField(sw_split, "no_stand", "SHORT")

with arcpy.da.UpdateCursor(
        sw_split,
        [seg_oid, "SIGN_OID", "no_stand", "SHAPE@"],
        explode_to_points=False) as cur:

    for sid, sign_oid, flag, seg in cur:
        arrow = sign_arrow.get(sign_oid)
        sig_pt = sign_geom.get(sign_oid)
        if not arrow or sig_pt is None:
            continue

        first, last = seg.firstPoint, seg.lastPoint
        res = arrow_map[arrow]

        if res == "both" \
           or (res == "before" and same(last, sig_pt)) \
           or (res == "after"  and same(first, sig_pt)):
            flag = 1
        else:
            flag = 0

        cur.updateRow([sid, sign_oid, flag, seg])

arcpy.AddMessage("✅   Segments flagged via endpoint logic")

# 4.5 write out
arcpy.management.DeleteField(sw_split, ["SIGN_OID"])
arcpy.management.CopyFeatures(sw_split, out_fc)
arcpy.AddMessage(f"🎉  Final no‑standing layer → {out_fc}")
