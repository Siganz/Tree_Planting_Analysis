import os
import pandas as pd
import arcpy

arcpy.env.overwriteOutput = True
scratch = arcpy.env.scratchGDB

# ── 0. Params ───────────────────────────────────────────────────────────────
# 0: csv_path, 1: sw_fc, 2: cen_fc, 3: out_fc, 4: desc_f, 5: side_f, 6: shift_ft
csv_path, sw_fc, cen_fc, out_fc, desc_f, side_f, shift_ft = [
    arcpy.GetParameterAsText(i) for i in range(7)
]
shift_ft = float(shift_ft)

# ── 0.1 Copy & integrate centerlines (don’t mutate source)───────────────────
cen_work = os.path.join(scratch, "cen_work")
arcpy.management.CopyFeatures(cen_fc, cen_work)
arcpy.management.Integrate(cen_work, "0.01 Feet")

# ── 1. load_filter() ─────────────────────────────────────────────────────────
def load_filter(csv_path, desc_f, side_f):
    df = pd.read_csv(csv_path)

    # normalize N/S/E/W
    df[side_f] = (df[side_f]
                  .astype(str).str.strip()
                  .str.upper().str[0]
                  .where(lambda s: s.isin(list("NSEW"))))
    df = df[df[side_f].notna()]

    # keep only our keywords
    keep = "NO STANDING|NO PARKING|HMP|TAXI|HOTEL|LOADING|PASSENGER"
    df = df[df[desc_f].str.upper().str.contains(keep, na=False)]

    # valid coords
    df = df[pd.to_numeric(df["sign_x_coord"], "coerce").notna()]
    df = df[pd.to_numeric(df["sign_y_coord"], "coerce").notna()]

    # dedupe on 1-ft grid
    df["x_r"] = df["sign_x_coord"].round(1)
    df["y_r"] = df["sign_y_coord"].round(1)
    df = df.drop_duplicates(subset=["x_r", "y_r"]).reset_index(drop=True)

    # parse arrow glyphs
    def _pa(s):
        s = str(s).upper()
        if "<->" in s:
            return "<->"
        elif "-->" in s or "->" in s:
            return "->"
        elif "<--" in s or "<-" in s:
            return "<-"
    df["parsed_arrow"] = df[desc_f].apply(_pa)
    df = df[df["parsed_arrow"].notna()]

    return df

# ── 1.1 Export clean CSV + to points ──────────────────────────────────────────

df = load_filter(csv_path, desc_f, side_f)        # <- pass the args
df["jid"] = df.index
tmp_csv = os.path.join(scratch, "clean_signs.csv")
# only export fields we need downstream
df.to_csv(tmp_csv, index=False, columns=["jid","sign_x_coord","sign_y_coord", side_f, "parsed_arrow"])
arcpy.AddMessage(f"Cleaned signs CSV → {tmp_csv}")

sr = arcpy.SpatialReference(2263)
signs = os.path.join(scratch, "signs_pts")
arcpy.management.XYTableToPoint(tmp_csv, signs,
                                "sign_x_coord", "sign_y_coord",
                                coordinate_system=sr)
arcpy.AddMessage(f"Signs → point FC: {signs}")

signs_snapped_cl = os.path.join(scratch, "signs_snapped_cl")  # path variable
arcpy.management.CopyFeatures(signs, signs_snapped_cl)        # copy here

# ── 2.0 snap points → centerline & join NEAR_FID ───────────────────────────
near_centerline = os.path.join(scratch, "near_centerline")
arcpy.analysis.GenerateNearTable(signs_snapped_cl, cen_work, near_centerline,
                                 search_radius="60 Feet",
                                 location="NO_LOCATION",
                                 angle="NO_ANGLE",
                                 closest="CLOSEST")

arcpy.AddMessage(f"Near table of point to centerline created: {near_centerline}")


# pull that NEAR_FID back onto signs
arcpy.management.JoinField(signs_snapped_cl, "OBJECTID", near_centerline, "IN_FID", ["NEAR_FID"])
arcpy.AddMessage("📌 Joined NEAR_FID onto signs.")

#cl_geom
cl_geom = {}
with arcpy.da.SearchCursor(cen_work, ["OID@", "SHAPE@"]) as scur:
    for oid, geom in scur:
        cl_geom[oid] = geom

# snap shifted sign points to centerline
with arcpy.da.UpdateCursor(signs_snapped_cl, ["SHAPE@", "NEAR_FID"]) as cur:
    for shp, nid in cur:
        if nid in cl_geom:
            dist = cl_geom[nid].measureOnLine(shp.centroid)  # cheaper than queryPoint
            new_geom = cl_geom[nid].positionAlongLine(dist)
            cur.updateRow([new_geom, nid])
        else:
            # no near centerline found (60 ft limit) — leave shape as‑is
            pass

arcpy.AddMessage(f"Snapped signs →  Snapped centerline: {signs_snapped_cl}")

# ── 3.0 curb offset (light cursor) ───────────────────────────────────────────
shifted = os.path.join(scratch, "signs_shifted")
arcpy.management.CopyFeatures(signs_snapped_cl, shifted)
with arcpy.da.UpdateCursor(shifted, ["SHAPE@", side_f]) as cur:
    for shp, sd in cur:
        off = {"N":(0,shift_ft), "S":(0,-shift_ft),
               "E":(shift_ft,0), "W":(-shift_ft,0)}.get(sd, (0,0))
        pt = shp.centroid
        cur.updateRow([arcpy.PointGeometry(arcpy.Point(pt.X+off[0], pt.Y+off[1]), sr), sd])
arcpy.AddMessage("↔️ Shifted signs off centerline.")

# ── 4.0 Prep sidewalk work ───────────────────────────

sw_work = os.path.join(scratch, "sw_work")  
arcpy.management.CopyFeatures(sw_fc, sw_work)
arcpy.AddMessage(f"Copied sidewalks → {sw_work}")

signs_snapped_sw = os.path.join(scratch, "signs_snapped_sw")  # path variable
arcpy.management.CopyFeatures(shifted, signs_snapped_sw)        # copy here

near_sidewalk = os.path.join(scratch, "near_sidewalk")
arcpy.analysis.GenerateNearTable(signs_snapped_sw, sw_work, near_sidewalk,
                                 search_radius="60 Feet",
                                 location="NO_LOCATION",
                                 angle="NO_ANGLE",
                                 closest="CLOSEST")

# pull that NEAR_FID back onto signs *before* snapping
arcpy.management.JoinField(signs_snapped_sw, "OBJECTID", near_sidewalk,
                            "IN_FID", ["NEAR_FID"])
arcpy.AddMessage("📌 Joined NEAR_FID onto curb‑shifted signs.")

# build {OID: geom} for the sidewalk layer
sw_geom = {oid: g for oid, g in arcpy.da.SearchCursor(sw_work, ["OID@", "SHAPE@"])}

# snap curb‑shifted points to the closest spot on their sidewalk
with arcpy.da.UpdateCursor(signs_snapped_sw, ["SHAPE@", "NEAR_FID"]) as cur:
    for shp, nid in cur:
        if nid in sw_geom:
            meas = sw_geom[nid].measureOnLine(shp.centroid)
            cur.updateRow([sw_geom[nid].positionAlongLine(meas), nid])

arcpy.AddMessage(f"Snapped signs → sidewalks: {signs_snapped_sw}")

# pull that NEAR_FID back onto shifted
arcpy.management.JoinField(signs_snapped_sw, "OBJECTID", near_sidewalk, "IN_FID", ["NEAR_FID"])
arcpy.AddMessage("📌 Joined NEAR_FID onto shifted signs.")

# ── 5.0 Split Sw ───────────────────────────
# ── 5.0  Split sidewalks at sign locations  ────────────────────────────────
sw_split = os.path.join(scratch, "sw_split")

# 1) empty copy of the sidewalk schema
arcpy.management.CreateFeatureclass(
    scratch, "sw_split", "POLYLINE",
    template=sw_work,
    spatial_reference=sw_work
)

# 2) load snapped‑to‑sidewalk sign points into RAM
sign_pts = [row[0] for row in arcpy.da.SearchCursor(signs_snapped_sw, ["SHAPE@"])]

TOL = 1  # feet

# 3) walk each sidewalk polyline and cut it wherever a sign touches
with arcpy.da.SearchCursor(sw_work, ["SHAPE@"]) as lcur, \
     arcpy.da.InsertCursor(sw_split, ["SHAPE@"]) as icur:

    for (line,) in lcur:
        # points lying on / very near this line
        on_line = [pt for pt in sign_pts if line.distanceTo(pt) <= TOL]

        # order points by distance along the line so cuts happen in sequence
        on_line.sort(key=lambda p: line.measureOnLine(p))

        pieces = [line]
        for pt in on_line:
            new_pieces = []
            for seg in pieces:
                cuts = seg.cut(pt)          # returns [left, right] or None
                new_pieces.extend(cuts or [seg])
            pieces = new_pieces

        for seg in pieces:
            icur.insertRow([seg])

arcpy.AddMessage(f"Split sidewalks at signs → {sw_split}")

# ------------------------------------------------------------
# 4.  tag 'before' vs 'after' using endpoint‑touch logic
# ------------------------------------------------------------
arrow_map = {"->": "after", "<-": "before", "<->": "both"}
seg_oid   = arcpy.Describe(sw_split).OIDFieldName
sw_split_joined_path = os.path.join(scratch, "sw_split_joined")  # unique var
if "SIGN_OID" not in [f.name for f in arcpy.ListFields(sw_split)]:
    arcpy.analysis.SpatialJoin(
        target_features = sw_split,
        join_features   = signs_snapped,
        out_feature_class = sw_split_joined_path,
        join_operation  = "JOIN_ONE_TO_ONE",   # or ONE_TO_MANY if you prefer
        match_option    = "INTERSECT"
    )
    sw_split = sw_split_joined_path
    arcpy.management.AlterField(sw_split, "TARGET_FID", new_field_name="SIGN_OID")

# -------------------------------------------------------------------
# helper dicts
sign_arrow = {oid: arr for oid, arr
              in arcpy.da.SearchCursor(signs_snapped,
                                       ["OBJECTID","parsed_arrow"])}
sign_geom  = {oid: geom for oid, geom
              in arcpy.da.SearchCursor(signs_snapped,
                                       ["OBJECTID","SHAPE@"])}

def same(pt, sig_pt, tol=0.05):                   # ~½‑inch tol
    return abs(pt.X - sig_pt.X) < tol and abs(pt.Y - sig_pt.Y) < tol
# -------------------------------------------------------------------
if "no_stand" not in [f.name for f in arcpy.ListFields(sw_split)]:
    arcpy.management.AddField(sw_split, "no_stand", "SHORT")

with arcpy.da.UpdateCursor(
        sw_split,
        [seg_oid, "SIGN_OID", "no_stand", "SHAPE@"],
        explode_to_points=False) as cur:

    for sid, sign_oid, flag, seg in cur:
        arrow = sign_arrow.get(sign_oid)
        sig_pt = sign_geom.get(sign_oid)
        if not arrow or sig_pt is None:
            continue

        first, last = seg.firstPoint, seg.lastPoint
        res = arrow_map[arrow]

        if res == "both" \
           or (res == "before" and same(last, sig_pt)) \
           or (res == "after"  and same(first, sig_pt)):
            flag = 1
        else:
            flag = 0

        cur.updateRow([sid, sign_oid, flag, seg])

arcpy.AddMessage("✅   Segments flagged via endpoint logic")

# 4.5 write out
arcpy.management.DeleteField(sw_split, ["SIGN_OID"])
arcpy.management.CopyFeatures(sw_split, out_fc)
arcpy.AddMessage(f"🎉  Final no‑standing layer → {out_fc}")
