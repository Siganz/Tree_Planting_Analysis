import sqlite3
from sqlalchemy import create_engine
from sqlalchemy.event import listen
from sqlalchemy.pool import StaticPool
import shapely.wkb

def prepare_spatialite_db(db_path, spatialite_extension_path):
    conn = sqlite3.connect(db_path)
    conn.enable_load_extension(True)
    conn.load_extension(spatialite_extension_path)
    conn.execute("SELECT InitSpatialMetaData(1);")
    return conn


def insert_gdf_to_spatialite(gdf, db_path, table_name, spatialite_extension_path):
    # Convert geometries to WKB
    gdf['geometry_wkb'] = gdf['geometry'].apply(lambda geom: shapely.wkb.dumps(geom))
    gdf = gdf.drop(columns='geometry')

    # Create SQLAlchemy engine
    engine = create_engine(f'sqlite:///{db_path}', connect_args={'check_same_thread': False}, poolclass=StaticPool)

    # Load SpatiaLite extension
    def load_spatialite(dbapi_conn, connection_record):
        dbapi_conn.enable_load_extension(True)
        dbapi_conn.load_extension(spatialite_extension_path)
        dbapi_conn.execute("SELECT InitSpatialMetaData(1);")
    listen(engine, 'connect', load_spatialite)

    # Write data to SQL
    gdf.to_sql(table_name, engine, if_exists='replace', index=False)

    # Add geometry column
    with engine.connect() as conn:
        conn.execute(f"SELECT AddGeometryColumn('{table_name}', 'geom', 4326, 'GEOMETRY', 2);")
        conn.execute(f"UPDATE {table_name} SET geom = GeomFromWKB(geometry_wkb, 4326);")
        conn.execute(f"ALTER TABLE {table_name} DROP COLUMN geometry_wkb;")
