from download_helpers import fetch_socrata_table

# Tree Points (GeoJSON + WKT)
gfl = fetch_socrata_table("https://data.cityofnewyork.us/resource/hn5i-inap.json?$limit=50000")
print("Tree points →", gfl[0][1].shape, gfl[0][2])   # e.g. (30240, …), 4326

# Work Orders
wofl = fetch_socrata_table("https://data.cityofnewyork.us/resource/xxxx-yyyy.json?$limit=50000")
print("Work orders →", wofl[0][1].shape, wofl[0][2])

# Planting Space
pfl = fetch_socrata_table("https://data.cityofnewyork.us/resource/zzzz-aaaa.json?$limit=50000")
print("Planting space →", pfl[0][1].shape, pfl[0][2])

# Street Signs
ssfl = fetch_socrata_table("https://data.cityofnewyork.us/resource/bbbb-cccc.json?$limit=50000")
print("Street signs →", ssfl[0][1].shape, ssfl[0][2])
